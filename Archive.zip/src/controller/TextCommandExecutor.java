package controller;

interface TextCommandExecutor {
  void executeCommand();
}
