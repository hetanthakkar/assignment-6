package model;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public abstract class AbstractPortfolioTest {
  PortfolioModel testPortfolio;;
}
